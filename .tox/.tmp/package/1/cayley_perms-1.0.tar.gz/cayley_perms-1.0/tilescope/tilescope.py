from comb_spec_searcher import CombinatorialSpecificationSearcher


class TileScope(CombinatorialSpecificationSearcher):
    pass
